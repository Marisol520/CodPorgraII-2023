package com.example.dramasv2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class Editar_S extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editar_s);
    }
}
