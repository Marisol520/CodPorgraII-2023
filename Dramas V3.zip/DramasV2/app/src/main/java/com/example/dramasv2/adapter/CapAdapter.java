package com.example.dramasv2.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.dramasv2.R;
import com.example.dramasv2.modelo.Video;
import java.util.List;

public class CapAdapter extends RecyclerView.Adapter<CapAdapter.VideoViewHolder> {

    private Context context;
    private List<Video> videoList;
    private OnVideoClickListener onVideoClickListener;

    public CapAdapter(Context context, List<Video> videoList, OnVideoClickListener onVideoClickListener) {
        this.context = context;
        this.videoList = videoList;
        this.onVideoClickListener = onVideoClickListener;
    }

    @NonNull
    @Override
    public VideoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.v_detalles, parent, false);
        return new VideoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VideoViewHolder holder, int position) {
        Video video = videoList.get(position);
        holder.bind(video, onVideoClickListener);
    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }

    public static class VideoViewHolder extends RecyclerView.ViewHolder {
        private TextView tvEpisodeTitle, tvEpisodeNumber;

        public VideoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEpisodeTitle = itemView.findViewById(R.id.tvEpisodeTitle);
            tvEpisodeNumber = itemView.findViewById(R.id.tvEpisodeNumber);
        }

        public void bind(Video video, OnVideoClickListener onVideoClickListener) {
            tvEpisodeTitle.setText(video.getTitle());
            tvEpisodeNumber.setText(String.valueOf(video.getChapterNumber()));
            itemView.setOnClickListener(v -> onVideoClickListener.onVideoClick(video));
        }
    }

    public interface OnVideoClickListener {
        void onVideoClick(Video video);
    }
}



