package com.example.dramasv2;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dramasv2.adapter.SerieAdapter;
import com.example.dramasv2.modelo.Serie;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SerieAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private SerieAdapter serieAdapter;
    private List<Serie> seriesList;
    private DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        seriesList = new ArrayList<>();
        serieAdapter = new SerieAdapter(this, seriesList);
        recyclerView.setAdapter(serieAdapter);
        serieAdapter.setOnItemClickListener(this);

        db = FirebaseDatabase.getInstance().getReference("series");
        loadSeriesFromDatabase();

        FloatingActionButton fabAgregar = findViewById(R.id.fab);
        fabAgregar.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Agrega_S.class);
            startActivityForResult(intent, 1);
        });

        ImageButton btnLogout = findViewById(R.id.action_logout);
        btnLogout.setOnClickListener(v -> logout());

        // Registrar el RecyclerView para el menú contextual
        registerForContextMenu(recyclerView);
    }

    private void loadSeriesFromDatabase() {
        db.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                seriesList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Serie serie = dataSnapshot.getValue(Serie.class);
                    seriesList.add(serie);
                }
                serieAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle error
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Manejar la respuesta de la actividad de agregar serie si es necesario
        }
    }

    @Override
    public void onItemClick(int position) {
        // Abre una actividad para editar la serie
        Serie clickedSerie = seriesList.get(position);
        Intent intent = new Intent(MainActivity.this, Editar_S.class);
        intent.putExtra("serie", clickedSerie);
        startActivity(intent);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu_1, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int position = serieAdapter.getPosition();
        Serie clickedSerie = seriesList.get(position);

        int itemId = item.getItemId();
        if (itemId == R.id.menu_editar) {// Abrir actividad para editar la serie
            Intent intent = new Intent(MainActivity.this, Editar_S.class);
            intent.putExtra("serie", clickedSerie);
            startActivity(intent);
            return true;
        } else if (itemId == R.id.menu_eliminar) {// Eliminar la serie tanto localmente como en Firebase
            String serie_n = clickedSerie.getId();
            db.child(serie_n).removeValue().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    seriesList.remove(position);
                    serieAdapter.notifyItemRemoved(position);
                    Toast.makeText(MainActivity.this, "Serie eliminada", Toast.LENGTH_SHORT).show();
                } else {
                    // Handle error
                }
            });
            return true;
        }
        return super.onContextItemSelected(item);
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(MainActivity.this, Login.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
