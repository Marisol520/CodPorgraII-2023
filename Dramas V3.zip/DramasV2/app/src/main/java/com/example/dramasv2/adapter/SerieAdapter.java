package com.example.dramasv2.adapter;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dramasv2.Capitulos_S;
import com.example.dramasv2.MainActivity;
import com.example.dramasv2.R;
import com.example.dramasv2.modelo.Serie;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class SerieAdapter extends RecyclerView.Adapter<SerieAdapter.SerieViewHolder> {
    private Context context;
    private List<Serie> seriesList;
    private DatabaseReference db;

    public SerieAdapter(Context context, List<Serie> seriesList) {
        this.context = context;
        this.seriesList = seriesList;
        this.db = FirebaseDatabase.getInstance().getReference("series");
    }

    @NonNull
    @Override
    public SerieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.detalles, parent, false);
        return new SerieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SerieViewHolder holder, int position) {
        Serie serie = seriesList.get(position);
        holder.bind(serie, position);
    }

    @Override
    public int getItemCount() {
        return seriesList.size();
    }

    public void setOnItemClickListener(MainActivity mainActivity) {
    }

    public int getPosition() {
        return 0;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class SerieViewHolder extends RecyclerView.ViewHolder {
        private TextView tvName, tvSynopsis, tvCategories, tvEpisodes;
        private ImageView imageView;

        public SerieViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvSynopsis = itemView.findViewById(R.id.tvSynopsis);
            tvCategories = itemView.findViewById(R.id.tvCategories);
            tvEpisodes = itemView.findViewById(R.id.tvEpisodes);
            imageView = itemView.findViewById(R.id.imageView);

            // Manejar clics largos en el item para mostrar un menú
            itemView.setOnLongClickListener(v -> {
                showPopupMenu(getAdapterPosition());
                return true;
            });
        }

        public void bind(Serie serie, int position) {
            tvName.setText(serie.getName());
            tvSynopsis.setText(serie.getSynopsis());
            tvCategories.setText(serie.getCategories());
            tvEpisodes.setText(serie.getEpisodes());

            // Cargar la imagen desde la Uri
            if (serie.getImageUri() != null) {
                imageView.setImageURI(serie.getImageUri());
            }

            // Manejar clics en el item
            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, Capitulos_S.class);
                intent.putExtra("serie", serie); // Asegúrate de que Serie implemente Serializable o Parcelable
                context.startActivity(intent);
            });
        }

        private void showPopupMenu(int position) {
            PopupMenu popupMenu = new PopupMenu(context, itemView);
            popupMenu.inflate(R.menu.menu_1);
            popupMenu.setOnMenuItemClickListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.menu_editar) {// Lógica para editar la serie
                    editSerie(position);
                    return true;
                } else if (itemId == R.id.menu_eliminar) {// Lógica para eliminar la serie
                    deleteSerie(position);
                    return true;
                }
                return false;
            });
            popupMenu.show();
        }

        private void editSerie(int position) {
            Serie serie = seriesList.get(position);
            // Aquí puedes iniciar una actividad para editar la serie
            Toast.makeText(context, "Editar " + serie.getName(), Toast.LENGTH_SHORT).show();
        }

        private void deleteSerie(int position) {
            Serie serie = seriesList.get(position);
            seriesList.remove(position);
            notifyItemRemoved(position);

            // Verificar si la lista está vacía antes de intentar eliminar de Firebase
            if (seriesList.isEmpty()) {
                // Mostrar un mensaje indicando que la lista está vacía
                Toast.makeText(context, "Lista de series vacía", Toast.LENGTH_SHORT).show();
            } else {
                // Eliminar la serie de Firebase
                String serie_n = serie.getId();
                db.child(serie_n).removeValue().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(context, "Serie eliminada", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Error al eliminar la serie", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
}

