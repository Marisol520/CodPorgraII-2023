package com.example.dramasv2.modelo;

public class Video {
    private String id;
    private String title;
    private String videoUrl;
    private int chapterNumber;

    public Video() {
        // Constructor vacío necesario para Firebase
    }

    public Video(String id, String title, String videoUrl, int chapterNumber) {
        this.id = id;
        this.title = title;
        this.videoUrl = videoUrl;
        this.chapterNumber = chapterNumber;
    }

    // Getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public int getChapterNumber() {
        return chapterNumber;
    }

    public void setChapterNumber(int chapterNumber) {
        this.chapterNumber = chapterNumber;
    }
}

